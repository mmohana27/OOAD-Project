//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

//import StudentController.ApplyJob;

public class StudentLogin {
    private String username;
    private String password;
    private float cgpa;
    private String Branch;
    private int year;
    private boolean placed;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public void setCGPA(float cgpa)
    {
    	this.cgpa = cgpa;
    }
    
    public void setBranch(String branch) {
        this.Branch = branch;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public void setPlaced(boolean placed)
    {
    	this.placed = placed;
    }
    
    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }
    
    public float getCGPA()
    {
    	return this.cgpa;
    }
    
    public String getBranch() {
        return this.Branch;
    }

    public int getYear() {
        return this.year;
    }
    
    public boolean getPlaced()
    {
    	return this.placed;
    }
    
    public void applyJob(String cName, String role) throws SQLException
    {
    	Connection conn = null;
	    try {
	        String url = "jdbc:mysql://localhost:3306/pms";
	        String user = "root";
	        String pass = "Mohana@1998";
	        conn = DriverManager.getConnection(url, user, pass);
	        System.out.println("Connected to MySQL database.");
	    } catch (SQLException e) {
	        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
	    }

	    //String name = userID.getText();
	    //String password = new String(pass.getPassword());

	    //String query = "SELECT password FROM students WHERE name = ?";
	    String query = "Insert into Applications values(?,?,?,?,1)";
	    //System.out.println(query);
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        //stmt.setString(1, name);
	    	stmt.setString(1, cName);
	    	stmt.setString(2, role);
	    	stmt.setString(3, username);
	    	stmt.setInt(4, year);
	    	System.out.println(stmt);
	    	//int rows=0;
	    	
	    	int rows = stmt.executeUpdate();
	        //return true;
	    }
	    
	    try{
	    	conn.close();
	    }
	    catch (SQLException e) {
	        System.out.println("Error closing: " + e.getMessage());
	    }
    }

    public boolean authenticate(String name,String password)
    {
        Connection conn = null;
	    try {
	        String url = "jdbc:mysql://localhost:3306/pms";
	        String user = "root";
	        String pass = "Mohana@1998";
	        conn = DriverManager.getConnection(url, user, pass);
	        System.out.println("Connected to MySQL database.");
	    } catch (SQLException e) {
	        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
	    }

    //String name = userID.getText();
    //String password = new String(pass.getPassword());

	    String query = "SELECT id, name, password, cgpa, year, Branch, Placed FROM students WHERE name = ?";
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        stmt.setString(1, name);
	        try (ResultSet rs = stmt.executeQuery()) {
	            if (rs.next()) {
	                String passwordFromDatabase = rs.getString("password");
	                if (passwordFromDatabase.equals(password)) {
	                    System.out.println("Login successful.");
	                    this.setUsername(name);
	                    this.setPassword(password);
	                    float cgpa_db = rs.getFloat("cgpa");
	                    int year_db = rs.getInt("year");
	                    String branch_db = rs.getString("Branch");
	                    boolean placed_db = rs.getBoolean("placed");
	                    this.setCGPA(cgpa_db);
	                    this.setYear(year_db);
	                    this.setBranch(branch_db);
	                    this.setPlaced(placed_db);
	                    //panel = StudentView.getPanel();
	                    return true;
	                } else {
	                    System.out.println("Invalid password.");
	                    return false;
	                }
	            } else {
	                System.out.println("User not found.");
	                return false;
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println("Error executing query: " + e.getMessage());
	    } 
	    try{
	    conn.close();
	    }
	    catch (SQLException e) {
	        System.out.println("Error closing: " + e.getMessage());
	    } 
	
	    return false;

    }

	public DefaultTableModel getOffers() {
		// TODO Auto-generated method stub
		List<String[]> data = new ArrayList<>(); 
		try {
           //Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/pms";
            String user = "root";
            String password = "Mohana@1998";
            Connection connection = DriverManager.getConnection(url, user, password);

            Statement statement = connection.createStatement();

	        String query = "SELECT * FROM offers where sName LIKE '"+this.username+"' and status = 0;";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String cName = resultSet.getString("cName");
                String role = resultSet.getString("role");
                //String sName = resultSet.getString("sName");
                int year = resultSet.getInt("year");
                String[] temp = new String[3];
                temp[0] = cName;
                temp[1] = role;
                temp[2] = Integer.toString(year);
                //System.out.println("Added row: "+temp[0]+temp[1]);
                data.add(temp);
            }
	            
            String[] columnNames = {"Company", "Role", "Year"};
                
            // create a new table model with the data and column names
            //DefaultTableModel model = new DefaultTableModel(data, columnNames);
	            
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            for (String[] row : data) {
                model.addRow(row);
            }
                
            // create a new JTable with the table model
            // JTable table = new JTable(model);
	            
            resultSet.close();
            statement.close();
            connection.close();
            return model;
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
		return null;
	}
    
	public void acceptOffer(String cName, String role, String sName) throws SQLException
	{
		Connection conn = null;
	    try {
	        String url = "jdbc:mysql://localhost:3306/pms";
	        String user = "root";
	        String pass = "Mohana@1998";
	        conn = DriverManager.getConnection(url, user, pass);
	        System.out.println("Connected to MySQL database.");
	    } catch (SQLException e) {
	        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
	    }

	    String query = "UPDATE offers SET status=2 WHERE cName LIKE ? AND role LIKE ? AND sName LIKE ?";
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	    	stmt.setString(1, cName);
	    	stmt.setString(2, role);
	    	stmt.setString(3, username);
	    	
	    	int rowsUpdated = stmt.executeUpdate();
	    	System.out.println(rowsUpdated + " rows updated.");
	    }
	    
	    query = "UPDATE students SET Placed = true WHERE name LIKE ?";
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	    	stmt.setString(1, username);
	    	
	    	int rowsUpdated = stmt.executeUpdate();
	    	System.out.println(rowsUpdated + " rows updated.");
	    }
	    
	    try{
	    	conn.close();
	    }
	    catch (SQLException e) {
	        System.out.println("Error closing: " + e.getMessage());
	    }
	}
	
	public void rejectOffer(String cName, String role, String sName) throws SQLException
	{
		Connection conn = null;
	    try {
	        String url = "jdbc:mysql://localhost:3306/pms";
	        String user = "root";
	        String pass = "Mohana@1998";
	        conn = DriverManager.getConnection(url, user, pass);
	        System.out.println("Connected to MySQL database.");
	    } catch (SQLException e) {
	        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
	    }
	    String query = "UPDATE offers SET status=1 WHERE cName LIKE ? AND role LIKE ? AND sName LIKE ?";
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	    	stmt.setString(1, cName);
	    	stmt.setString(2, role);
	    	stmt.setString(3, username);
	    	
	    	int rowsUpdated = stmt.executeUpdate();
	    	System.out.println(rowsUpdated + " rows updated.");
	    }
	    try{
	    	conn.close();
	    }
	    catch (SQLException e) {
	        System.out.println("Error closing: " + e.getMessage());
	    }
	}
	
	
	public DefaultTableModel getAvailableJobs()
	{
		String[] columnNames = {"Company", "Role", "Stipend", "JD", "Branch", "Cutoff", "Year"};
		DefaultTableModel model = new DefaultTableModel(columnNames, 0);
		List<String[]> data = new ArrayList<>(); 
		try {
            //Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/pms";
            String user = "root";
            String password = "Mohana@1998";
            Connection connection = DriverManager.getConnection(url, user, password);

            Statement statement = connection.createStatement();

            String query = "SELECT * FROM jobs where status = 1 and branch LIKE '"+Branch+
            		"' and cutoff <= "+Float.toString(cgpa)+";"; // made changes
            System.out.println(query);
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String cName = resultSet.getString("cName");
                String role = resultSet.getString("role");
                String JD = resultSet.getString("jd");
                String Branch = resultSet.getString("branch");
                int stipend = resultSet.getInt("stipend");
                float cutoff = resultSet.getFloat("cutoff");
                String[] temp = new String[6];
                temp[0] = cName; temp[1] = role ; temp[2] = JD ;
                temp[3] = Branch; temp[4] = String.valueOf(stipend);
                temp[5] = String.valueOf(cutoff);
                //System.out.println("Added row: "+temp[0]+temp[1]);
                data.add(temp);
            }
            
            //String[] columnNames = {"Company", "Role", "Stipend", "JD", "Branch", "Cutoff", "Year"};
            
            // create a new table model with the data and column names
            //DefaultTableModel model = new DefaultTableModel(data, columnNames);
            int n = 0;
            //DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            for (String[] row : data) {
                model.addRow(row);
                n++;
            }
            
            System.out.println("model size is:"+n);
            
            //view.addToTable(model);
            //view.applyJobListener(new ApplyJob());
            
            // create a new JTable with the table model
            // JTable table = new JTable(model);
            
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
		
		return model;
	}
	
	
}

