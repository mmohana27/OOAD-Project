import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StudentView extends JFrame {
    private JLabel usernameLabel;
    private JTextField usernameField;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton getOffersButton;
    private JButton acceptButton;
    private JButton rejectButton;
    private JLabel statusLabel;
    private JPanel panel;
    private GridBagConstraints constraints;
    
    //###
    private JButton getJobsButton;
	private JTable table;
	private JTable offerTable;
	//private GridBagConstraints constraints = new GridBagConstraints();
	//private JPanel panel = new JPanel(new GridBagLayout());
	private JButton applyButton;

    public StudentView() {
        super("Student Login");

        panel = new JPanel(new GridBagLayout());
        constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;

        usernameLabel = new JLabel("Username:");
        panel.add(usernameLabel, constraints);

        usernameField = new JTextField(20);
        constraints.gridx = 1;
        panel.add(usernameField, constraints);

        constraints.gridy = 1;
        constraints.gridx = 0;
        passwordLabel = new JLabel("Password:");
        panel.add(passwordLabel, constraints);

        passwordField = new JPasswordField(20);
        constraints.gridx = 1;
        panel.add(passwordField, constraints);

        constraints.gridy = 2;
        loginButton = new JButton("Login");
        panel.add(loginButton, constraints);

        constraints.gridy = 3;
        statusLabel = new JLabel();
        panel.add(statusLabel, constraints);

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public String getUsername() {
        return usernameField.getText();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    public void addLoginListener(ActionListener listener) {
        loginButton.addActionListener(listener);
    }
    
    public void displayGetJobs()
    {
    	//super("Student Apply");
        //super.setSize(1600,800);
        //super.setPreferredSize(new Dimension(1600, 800));

        //GridBagConstraints constraints = new GridBagConstraints();
    	
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        
        getJobsButton = new JButton("Get Jobs");
        panel.add(getJobsButton, constraints);
        
        applyButton = new JButton("Apply!");
    	constraints.gridx= 85;
    	constraints.gridy = 1;
    	panel.add(applyButton,constraints);
    	applyButton.setVisible(false);

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public void displayOfferTable() {
    	constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 0;
        
        getOffersButton = new JButton("View Offers");
        panel.add(getOffersButton, constraints);
        
        acceptButton = new JButton("Accept");
    	constraints.gridx= 35;
    	constraints.gridy = 2;
    	panel.add(acceptButton, constraints);
    	acceptButton.setVisible(false);
    	rejectButton = new JButton("Reject");
    	constraints.gridx= 65;
    	constraints.gridy = 2;
    	panel.add(rejectButton, constraints);
    	rejectButton.setVisible(false);

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    
    // ###### Getting from student view jobs:
    public void addGetJobsListener(ActionListener listener) {
        getJobsButton.addActionListener(listener);
    }
    
    public void hideGetJobs()
    {
    	getJobsButton.setVisible(false);
    }
    
    public void addGetOffersListener(ActionListener listener) {
    	getOffersButton.addActionListener(listener);
    }
    
    public void hideViewOffers()
    {
    	getOffersButton.setVisible(false);
    }
    
    public void addToTable(DefaultTableModel model)
    {
    	//System.out.println("Add to table called!");
    	table = new JTable(model);
    	
    	constraints.gridx = 80;
    	constraints.gridy = 1;
    	table.setPreferredScrollableViewportSize(new Dimension(30, 40));
    	panel.add(table, constraints);
    	
    	applyButton.setVisible(true);
    	
    	//applyButton = new JButton("Apply!");
    	//constraints.gridx= 85;
    	//constraints.gridy = 1;
    	//panel.add(applyButton,constraints);
    	
    }
    
    public void addToOfferTable(DefaultTableModel model)
    {
    	offerTable = new JTable(model);
    	constraints.gridx = 80;
    	constraints.gridy = 1;
    	offerTable.setPreferredScrollableViewportSize(new Dimension(30, 40));
    	panel.add(offerTable, constraints);
    	
    	acceptButton.setVisible(true);
    	rejectButton.setVisible(true);
    }
    
    public void applyJobListener(ActionListener listener) 
    {
    	applyButton.addActionListener(listener);
    	System.out.println("Apply Clicked!");
    }
    
    public void acceptOfferListener(ActionListener listener)
    {
    	acceptButton.addActionListener(listener);
    	System.out.println("Accept Offer Clicked");
    }
    
    public void rejectOfferListener(ActionListener listener)
    {
    	rejectButton.addActionListener(listener);
    	System.out.println("Reject Offer Clicked");
    }

    public String[] getRowDetails()
    {
    	String[] row = new String[2];
    	
    	int rowno = table.getSelectedRow();
    	
    	row[0] = (String) table.getValueAt(rowno, 0);
    	row[1] = (String) table.getValueAt(rowno, 1);
    	
    	return row;
    }
    
    public String[] getOfferRowDetails()
    {
    	String[] row = new String[3];
    	
    	int rowno = offerTable.getSelectedRow();
    	
    	row[0] = (String) offerTable.getValueAt(rowno, 0);
    	row[1] = (String) offerTable.getValueAt(rowno, 1);
    	row[2] = (String) offerTable.getValueAt(rowno, 2);
    	
    	return row;
    }
    
    public void clearPanel() {
    	panel.removeAll();
    	panel.revalidate();
    	panel.repaint();
    }
    
    public void displayDialog(String res)
    {
    	 JOptionPane.showMessageDialog(panel, res);
    	    
    	    
    	System.out.println("Display Dialog called");
    }
    
    
    
}
