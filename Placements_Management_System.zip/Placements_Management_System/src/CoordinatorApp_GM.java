public class CoordinatorApp_GM {
	public static void main(String args[])
	{
		CoordinatorController_GM a=new CoordinatorController_GM();
	}

}
