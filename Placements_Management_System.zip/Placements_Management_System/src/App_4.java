public class App_4 {
	public App_4()
	{
		view_4 v=new view_4();
		model_4 m=new model_4();
		controller_4 c=new controller_4(m,v);
	}

}
