public class CompanyApp {
    public static void main(String[] args) {
        Company model = new Company();
        CompanyView view = new CompanyView();
        CompanyController controller = new CompanyController(model, view);
    }
}