public class StudentLoginApp {
    public static void main(String[] args) {
        StudentLogin model = new StudentLogin();
        StudentView view = new StudentView();
        //StudentApplyView view2 = new StudentApplyView();
        //StudentViewJobs view3 = new StudentViewJobs();
        
        StudentController controller = new StudentController(model, view);
    }
}