import java.sql.*;

public class Company {
    private String company;
    private String password;

    public void setUsername(String username) {
        this.company = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public boolean createJobPost(String role,int stipend , String JD,String branch,float cutoff,int year) throws SQLException
	{
		
		
		 Connection conn = null;
		    try {
		        String url = "jdbc:mysql://localhost:3306/pms";
		        String user = "root";
		        String pass = "Mohana@1998";
		        conn = DriverManager.getConnection(url, user, pass);
		        System.out.println("Connected to MySQL database.");
		    } catch (SQLException e) {
		        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
		        return false;
		    }

		    //String name = userID.getText();
		    //String password = new String(pass.getPassword());

		    //String query = "SELECT password FROM students WHERE name = ?";
		    String query = "Insert into jobs values(?,?,?,?,?,?,true)";
		    try (PreparedStatement stmt = conn.prepareStatement(query)) {
		        //stmt.setString(1, name);
		    	stmt.setString(1, company);
		    	stmt.setString(2,role);
		    	stmt.setInt(5, stipend);
		    	stmt.setString(3, JD);
		    	stmt.setString(4, branch);
		    	stmt.setFloat(6, cutoff);
		    	//int rows=0;
		    	
		    	int rows = stmt.executeUpdate();
		        //return true; 
		    try{
		    conn.close();
		    }
		    catch (SQLException e) {
		        System.out.println("Error closing: " + e.getMessage());
		        return false;
		    } 
		    
		    return true;

		  

		
		
	}
	}
    
    public void createOffer(String Role, String sName, int year)
    {
    	Connection conn = null;
    	try {
            String url = "jdbc:mysql://localhost:3306/pms";
            String user = "root";
            String pass = "Mohana@1998";
            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Connected to MySQL database.");
            String query = "Insert into offers values (?,?,?,?,0)";
		    try (PreparedStatement stmt = conn.prepareStatement(query)) {
		        //stmt.setString(1, name);
		    	stmt.setString(1, company);
		    	stmt.setString(2, Role);
		    	stmt.setString(3, sName);
		    	stmt.setInt(4, year);
		    	//int rows=0;
		    	int rows = stmt.executeUpdate();
		    	
        } catch (SQLException e) {
            System.out.println("Failed to connect to MySQL database: " + e.getMessage());
        }
    	}
    	catch (SQLException e1) {
            System.out.println("Failed to connect to MySQL database: " + e1.getMessage());
        }
    	try{
		    conn.close();
		    }
		    catch (SQLException e) {
		        System.out.println("Error closing: " + e.getMessage());
		        //return false;
		    } 
    }

    	public boolean authenticate(String name,String password)
        {
            Connection conn = null;
    try {
        String url = "jdbc:mysql://localhost:3306/pms";
        String user = "root";
        String pass = "Mohana@1998";
        conn = DriverManager.getConnection(url, user, pass);
        System.out.println("Connected to MySQL database.");
    } catch (SQLException e) {
        System.out.println("Failed to connect to MySQL database: " + e.getMessage());
    }

    //String name = userID.getText();
    //String password = new String(pass.getPassword());

    String query = "SELECT Password FROM company WHERE cName = ?";
    try (PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, name);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String passwordFromDatabase = rs.getString("password");
                if (passwordFromDatabase.equals(password)) {
                    System.out.println("Login successful.");
                    return true;
                } else {
                    System.out.println("Invalid password.");
                    return false;
                }
            } else {
                System.out.println("User not found.");
                return false;
            }
        }
    } catch (SQLException e) {
        System.out.println("Error executing query: " + e.getMessage());
    } 
    try{
    conn.close();
    }
    catch (SQLException e) {
        System.out.println("Error closing: " + e.getMessage());
    } 

    return false;

        } 
}
