import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.util.*;
import javax.swing.*;


public class StudentViewJobs extends JFrame {
    
	
	private JComboBox jobOptions ;//= new JComboBox();
	private JComboBox comboBox ;//= new JComboBox();
	private JButton getJobsButton;
	private JTable table ;
	private GridBagConstraints constraints = new GridBagConstraints();
	private JPanel panel = new JPanel(new GridBagLayout());
	private JButton applyButton;
	//comboBox.addItem("Item 1");
	//comboBox.addItem("Item 2");
	
	


    public StudentViewJobs() {
        super("Student Apply");
        //super.setSize(1600,800);
        super.setPreferredSize(new Dimension(1600, 800));

        
        //GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        
        getJobsButton = new JButton("getJobs");
        panel.add(getJobsButton, constraints);
        
        applyButton = new JButton("Apply!");
    	constraints.gridx= 85;
    	constraints.gridy = 1;
    	panel.add(applyButton,constraints);
    	applyButton.setVisible(false);
        
        
        //constraints.gridx = 1;
        //comboBox = new JComboBox();
        //panel.add(comboBox,constraints);

        

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public void addLoginListener(ActionListener listener) {
        getJobsButton.addActionListener(listener);
    }
    
    public void addToTable(DefaultTableModel model)
    {
    	table = new JTable(model);
    	constraints.gridx = 80;
    	constraints.gridy = 1;
    	table.setPreferredScrollableViewportSize(new Dimension(30, 40));
    	panel.add(table,constraints);
    	
    	applyButton.setVisible(true);
    	
    	//applyButton = new JButton("Apply!");
    	//constraints.gridx= 85;
    	//constraints.gridy = 1;
    	//panel.add(applyButton,constraints);
    	
    }
    
    public void applyJobListener(ActionListener listener) 
    {
    	applyButton.addActionListener(listener);
    	System.out.println("Apply Clicked!");
    }
    
    
    public String[] getRowDetails()
    {
    	String[] row = new String[2];
    	
    	int rowno = table.getSelectedRow();
    	
    	row[0] = (String) table.getValueAt(rowno, 0);
    	row[1] = (String) table.getValueAt(rowno, 1);
    	
    	
    	
    	return row;
    }
    
	
	
    }