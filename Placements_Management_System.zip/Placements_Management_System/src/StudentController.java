import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.sql.*;

public class StudentController {
    private StudentLogin model;
    private StudentView view;
    //private StudentApplyView view2;
    private StudentViewJobs view3;

    public StudentController(StudentLogin model, StudentView view) {
        this.model = model;
        this.view = view;

        view.addLoginListener(new LoginListener());
    }
 
    public StudentController(StudentLogin model, StudentViewJobs view) {
        this.model = model;
        this.view3 = view;

        view.addLoginListener(new GetJobs());
        view3.applyJobListener(new ApplyJob());
    }

    class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = view.getUsername();
            String password = view.getPassword();

            model.setUsername(username);
            model.setPassword(password);

            boolean success = model.authenticate(username,password);

            if (success) {
                view.setStatus("Login successful");
                view.clearPanel();
                view.displayGetJobs();
                view.displayOfferTable();
                view.addGetJobsListener(new GetJobs());
                view.addGetOffersListener(new GetOffers());
                view.displayDialog("Succesful login!");
                
                if(model.getPlaced())
                {
                	view.displayDialog("Congrats on getting placed!!!");
                	view.dispose();
                }
                
                //view3 = new StudentViewJobs();
                
                
            } else {
                view.setStatus("Login failed");
            }
        }
    }
    
    
    class ApplyJob implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String[] row = view.getRowDetails();
			
			try {
				model.applyJob(row[0], row[1]);
				view.displayDialog("Applied!");
				System.out.println("Applied!");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
    	
    }
    
    class AcceptOffer implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String[] row = view.getOfferRowDetails();
			
			try {
				model.acceptOffer(row[0], row[1], row[2]);
				view.displayDialog("Offer Accepted!");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
    	
    }
    
    class RejectOffer implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			String[] row = view.getOfferRowDetails();
			
			try {
				model.rejectOffer(row[0], row[1], row[2]);
				view.displayDialog("Offer Rejected!");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
    	
    }
  /*  
    class GetJobs implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			view.hideGetJobs();
			view.hideViewOffers();
			List<String[]> data = new ArrayList<>(); 
			try {
	            //Class.forName("com.mysql.cj.jdbc.Driver");

	            String url = "jdbc:mysql://localhost:3306/pms";
	            String user = "root";
	            String password = "@Classv38";
	            Connection connection = DriverManager.getConnection(url, user, password);

	            Statement statement = connection.createStatement();

	            String query = "SELECT * FROM jobs where status = 1 and branch LIKE '"+model.getBranch()+
	            		"' and cutoff <= "+Float.toString(model.getCGPA())+";"; // made changes
	            System.out.println(query);
	            ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	                String cName = resultSet.getString("cName");
	                String role = resultSet.getString("role");
	                String JD = resultSet.getString("jd");
	                String Branch = resultSet.getString("branch");
	                int stipend = resultSet.getInt("stipend");
	                float cutoff = resultSet.getFloat("cutoff");
	                String[] temp = new String[6];
	                temp[0] = cName; temp[1] = role ; temp[2] = JD ;
	                temp[3] = Branch; temp[4] = String.valueOf(stipend);
	                temp[5] = String.valueOf(cutoff);
	                //System.out.println("Added row: "+temp[0]+temp[1]);
	                data.add(temp);
	            }
	            
	            String[] columnNames = {"Company", "Role", "Stipend", "JD", "Branch", "Cutoff", "Year"};
                
                // create a new table model with the data and column names
                //DefaultTableModel model = new DefaultTableModel(data, columnNames);
	            int n = 0;
	            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
	            for (String[] row : data) {
	                model.addRow(row);
	                n++;
	            }
	            
	            System.out.println("model size is:"+n);
	            
	            view.addToTable(model);
	            view.applyJobListener(new ApplyJob());
                
                // create a new JTable with the table model
                // JTable table = new JTable(model);
	            
	            resultSet.close();
	            statement.close();
	            connection.close();
	        } catch (SQLException e1) {
	            e1.printStackTrace();
	        }
		}
    }
    */
    
    class GetJobs implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			view.hideGetJobs();
			view.hideViewOffers();
			
			DefaultTableModel model1 = model.getAvailableJobs();
			
			
			   view.addToTable(model1);
	           view.applyJobListener(new ApplyJob());
			
		}
    }
    
    
    
    
    
    
    class GetOffers implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			view.hideViewOffers();
			view.hideGetJobs();
			
			view.addToOfferTable(model.getOffers());
			view.acceptOfferListener(new AcceptOffer());
			view.rejectOfferListener(new RejectOffer());
		}
    }
}

