public class CoordinatorApp2 {
	public CoordinatorApp2()
	{
		Coordinatorview2 v=new Coordinatorview2();
		CoordinatorModel2 m=new CoordinatorModel2();
		CoordinatorController2 c=new CoordinatorController2(m,v);
	}

}
