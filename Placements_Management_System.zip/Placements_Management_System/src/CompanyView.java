import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CompanyView extends JFrame {
    private JLabel usernameLabel;
    private JTextField usernameField;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton addJobs;
    //private JButton getInfo;
    private JButton createJobButton;
    private JLabel statusLabel;
    private JButton getStudents;
    private JTable table ;
    private JButton sendOffer;
    
    private JPanel panel;
    
    private JLabel LRole;
    private JTextField TRole;
    
    private JLabel LStipend;
    private JTextField TStipend;
    
    private JLabel LJD;
    private JTextField TJD;
    
    private JLabel LBranch;
    private JTextField TBranch;
    
    private JLabel LCutoff;
    private JTextField TCutoff;
    
    private JLabel LYear;
    private JTextField TYear;
    
    private GridBagConstraints constraints;

    public CompanyView() {
        super("Company Login");

        panel = new JPanel(new GridBagLayout());
        constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;

        usernameLabel = new JLabel("Company:");
        panel.add(usernameLabel, constraints);

        usernameField = new JTextField(20);
        constraints.gridx = 1;
        panel.add(usernameField, constraints);

        constraints.gridy = 1;
        passwordLabel = new JLabel("Password:");
        constraints.gridx = 0;
        panel.add(passwordLabel, constraints);

        passwordField = new JPasswordField(20);
        constraints.gridx = 1;
        panel.add(passwordField, constraints);

        constraints.gridy = 2;
        loginButton = new JButton("Login");
        panel.add(loginButton, constraints);

        constraints.gridy = 3;
        statusLabel = new JLabel();
        panel.add(statusLabel, constraints);

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public String getUsername() {
        return usernameField.getText();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    public void addLoginListener(ActionListener listener) {
    	//System.out.println("INIT lOGIN BUTTON");
        loginButton.addActionListener(listener);
    }
    
    public void addEnterJobsListener(ActionListener listener)
    {
    	createJobButton.addActionListener(listener);
    }
    
    public void addGoToJobEntry(ActionListener listener)
    {
    	//System.out.println("INIT BUTTON");
    	addJobs.addActionListener(listener); 
    }
    
    //To List the Students who have Applied for the Listed Job - 
    public void listStudents(ActionListener listener)
    {
    	System.out.println("Button Clicked");
    	getStudents.addActionListener(listener);
    }
    
    public void addToTable(DefaultTableModel model)
    {
    	table = new JTable(model);
    	constraints.gridx = 80;
    	constraints.gridy = 1;
    	table.setPreferredScrollableViewportSize(new Dimension(30, 40));
    	panel.add(table,constraints);
    	
    
    	//applyButton.setVisible(true);
    	
    	//applyButton = new JButton("Apply!");
    	//constraints.gridx= 85;
    	//constraints.gridy = 1;
    	//panel.add(applyButton,constraints);
    	
    }
    
    public String[] getRowDetails()
    {
    	String[] row = new String[4];
    	
    	int rowno = table.getSelectedRow();
    	
    	row[0] = (String) table.getValueAt(rowno, 0); //cName
    	row[1] = (String) table.getValueAt(rowno, 1); //role
    	row[2] = (String) table.getValueAt(rowno, 2); //sName
    	row[3] = (String) table.getValueAt(rowno, 3); //year
    	
    	return row;
    }
    
    public void offerJob(ActionListener listener) 
    {
    	sendOffer.addActionListener(listener);
    	System.out.println("Job Offered!");
    }
    
    public void addCreateOfferButton()
    {
    	sendOffer = new JButton("Send Offer");
    	constraints.gridx = 85;
    	constraints.gridy = 1;
    	panel.add(sendOffer, constraints);
    }
    
    public void clearPanel()
    {
        panel.removeAll();
        panel.revalidate();
        panel.repaint();
    }
    
    
    public void button()
    {
    	constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        
        //constraints.gridy = 2;
        addJobs = new JButton("Add Jobs");
        panel.add(addJobs, constraints);
        
        constraints.gridy = 2;
        getStudents = new JButton("Retrieve Student List");
        panel.add(getStudents, constraints);
    }
    
    
    
    public void addJobsEntry()
    {
    	constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        
        constraints.gridx = 1;
        constraints.gridy = 1;
        LRole = new JLabel("Role:");
        panel.add(LRole, constraints);
        
        
        TRole = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 2;
        panel.add(TRole, constraints);

        constraints.gridx = 1;
        constraints.gridy = 3;
        //constraints.gridy = 1;
        LStipend = new JLabel("Stipend:");
        panel.add(LStipend, constraints);
        
        TStipend = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 4;
        //constraints.gridy = 2;
        panel.add(TStipend, constraints);
        
        
        
        LJD = new JLabel("JD: ");
        constraints.gridy = 5;
        constraints.gridx = 1;
        //constraints.gridy = 3;
        panel.add(LJD, constraints);
        
        TJD = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 6;
        //constraints.gridy = 4;
        panel.add(TJD, constraints);
        
        LBranch = new JLabel("Branch: ");
        constraints.gridx = 1;
        constraints.gridy = 7;
        panel.add(LBranch, constraints);
        
        TBranch = new JTextField(20);
        constraints.gridy = 8;
        constraints.gridx = 1;
        panel.add(TBranch, constraints);
        
        LCutoff = new JLabel("Cutoff: ");
        constraints.gridy = 9;
        constraints.gridx = 1;
        panel.add(LCutoff, constraints);
        
        TCutoff = new JTextField(20);
        constraints.gridy = 10;
        constraints.gridx = 1;
        panel.add(TCutoff, constraints);
        
        LYear = new JLabel("Year: ");
        constraints.gridy = 11;
        constraints.gridx = 1;
        panel.add(LYear, constraints);
        
        TYear = new JTextField(20);
        constraints.gridy = 12;
        constraints.gridx = 1;
        panel.add(TYear, constraints);
        
        constraints.gridx = 1;

        constraints.gridy = 15;
        createJobButton = new JButton("Add Job");
        panel.add(createJobButton, constraints);

        
        constraints.gridx = 13;
        constraints.gridy = 3;
        statusLabel = new JLabel();
        panel.add(statusLabel, constraints);

        add(panel);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    
    public String getRole() {
    	return TRole.getText();
    }
    
    public int getStipend() {
    	return Integer.parseInt(TStipend.getText());
    }
    
    public String getJD() {
    	return TJD.getText();
    }
    
    public String getBranch() {
    	return TBranch.getText();
    }
    
    public float getCutoff() {
    	return Float.parseFloat(TCutoff.getText());
    }
    
    public int getYear() {
    	return Integer.parseInt(TYear.getText());
    }
    
    public void displayDialog(String res)
    {
    	 JOptionPane.showMessageDialog(panel, res);
    	    
    	    
    	System.out.println("Display Dialog called");
    }
    
    
}
