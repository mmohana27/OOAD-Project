import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import com.mysql.cj.xdevapi.Statement;

public class CompanyController {
    private Company model;
    private CompanyView view;

    public CompanyController(Company model, CompanyView view) {
        this.model = model;
        this.view = view;

        view.addLoginListener(new LoginListener());
        //view.addLoginListener(new JobEntryListener());
        //view.addEnterJobsListener(new JobEntryListener());
    }

    class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = view.getUsername();
            String password = view.getPassword();

            model.setUsername(username);
            model.setPassword(password);

            boolean success = model.authenticate(username,password);

            if (success) {
                view.setStatus("Login successful");
                view.displayDialog("Login Successful");
                view.clearPanel();
                //
                
                //view.addJobsEntry();
                model.setUsername(username);
                //view.addLoginListener(new JobEntryListener());
                view.button();
                view.addGoToJobEntry(new goToJobEntry());
                view.listStudents(new listAppliedStudents());
            } else {
                view.setStatus("Login failed");
            }
        }
    }
    
    class goToJobEntry implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			view.clearPanel();
			view.addJobsEntry();
			view.addEnterJobsListener(new JobEntryListener());
			//view.addGoToJobEntry(new JobEntryListener());
			
		}
    	
    }
    
    class JobEntryListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
        	/*
            String username = view.getUsername();
            String password = view.getPassword();

            model.setUsername(username);
            model.setPassword(password);
            */
        	
        	//String cName = model.cName;
        	
        	String role = view.getRole();
        	String jd = view.getJD();
        	int stipend = view.getStipend();
        	String branch = view.getBranch();
        	float cutoff = view.getCutoff();
        	int year = view.getYear();
        	

            //boolean success = model.authenticate(username,password);
        	boolean success = false;
			try {
				success = model.createJobPost(role, stipend, jd, branch, cutoff, year);
				view.displayDialog("Job Entered!");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            if (success) {
                view.setStatus("Entered!");
                //view.addGoToJobEntry(new JobEntryListener());
                view.addEnterJobsListener(new JobEntryListener());
            } else {
                view.setStatus("Failed to enter");
            }
        }
    }
    
    class listAppliedStudents implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String username = view.getUsername();
            String password = view.getPassword();
			view.clearPanel();
			List<String[]> data = new ArrayList<>();
			try {
				String url = "jdbc:mysql://localhost:3306/pms";
	            String user = "root";
	            String pass = "Mohana@1998";
	            Connection connection = DriverManager.getConnection(url, user, pass);
	            
	            java.sql.Statement statement = connection.createStatement();

	            String query = "SELECT * FROM Applications where cName = '"+username+"';";
	            ResultSet resultSet = statement.executeQuery(query);
	            
	            while (resultSet.next())
	            {
	            	String cName = resultSet.getString("cName");
	                String role = resultSet.getString("role");
	                String student = resultSet.getString("sName");
	                int year = resultSet.getInt("year");
	                //float cutoff = resultSet.getFloat("cutoff");
	                String[] temp = new String[5];
	                temp[0] = cName; 
	                temp[1] = role ; 
	                temp[2] = student ;
	                temp[3] = String.valueOf(year);
	                //System.out.println("Added row: "+temp[0]+temp[1]);
	                data.add(temp);
	            }
	            
	            String[] columnNames = {"Company", "Role", "Student", "Year", "Stipend"};
	            
	            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
	            for (String[] row : data) {
	                model.addRow(row);
	            }
	            
	            view.addToTable(model);
	            view.addCreateOfferButton();
	            view.offerJob(new makeOffers());
			}
			catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
    	
    }
    
    class makeOffers implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String[] row = view.getRowDetails(); //4
			model.createOffer(row[1], row[2], Integer.parseInt(row[3]));
			view.displayDialog("Offer Made!");
			}
    	
    }
    
    
}